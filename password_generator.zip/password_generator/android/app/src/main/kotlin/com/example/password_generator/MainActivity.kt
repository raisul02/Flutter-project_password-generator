package com.example.password_generator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
