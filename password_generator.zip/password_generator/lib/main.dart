import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  runApp(PasswordGeneratorApp());
}

class PasswordGeneratorApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: PasswordGenerator(),
    );
  }
}

class PasswordGenerator extends StatefulWidget {
  @override
  _PasswordGeneratorState createState() => _PasswordGeneratorState();
}

class _PasswordGeneratorState extends State<PasswordGenerator> {
  String _password = "";
  bool _generated = false;

  bool _includeUppercase = true;
  bool _includeLowercase = true;
  bool _includeNumbers = true;
  bool _includeSpecial = true;

  TextEditingController _lengthController = TextEditingController(text: '8');

  String _generatePassword(int length) {
    const String upper = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const String lower = 'abcdefghijklmnopqrstuvwxyz';
    const String numbers = '0123456789';
    const String special = '!@#\$%^&*(),.?":{}|<>';

    String chars = '';
    if (_includeUppercase) chars += upper;
    if (_includeLowercase) chars += lower;
    if (_includeNumbers) chars += numbers;
    if (_includeSpecial) chars += special;

    if (chars.isEmpty) return "";

    Random rnd = Random();
    return List.generate(length, (index) => chars[rnd.nextInt(chars.length)]).join();
  }

  void _generate() {
    setState(() {
      int length = int.tryParse(_lengthController.text) ?? 8;
      _password = _generatePassword(length);
      _generated = true;
    });
  }

  void _update() {
    if (!_generated) {
      _showError('Generate password first!');
      return;
    }
    setState(() {
      int length = int.tryParse(_lengthController.text) ?? 8;
      _password = _generatePassword(length);
    });
  }

  void _copyToClipboard() {
    if (!_generated) {
      _showError('Generate password first!');
      return;
    }
    Clipboard.setData(ClipboardData(text: _password));
    _showSuccess('Password copied to clipboard!');
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.red),
    );
  }

  void _showSuccess(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.green),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Password Generator'),
        backgroundColor: Colors.teal,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            TextField(
              controller: _lengthController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: 'Length'),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Checkbox(
                    value: _includeUppercase,
                    onChanged: (val) => setState(() => _includeUppercase = val!)),
                Text('Uppercase'),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Checkbox(
                    value: _includeLowercase,
                    onChanged: (val) => setState(() => _includeLowercase = val!)),
                Text('Lowercase'),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Checkbox(
                    value: _includeNumbers,
                    onChanged: (val) => setState(() => _includeNumbers = val!)),
                Text('Numbers'),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Checkbox(
                    value: _includeSpecial,
                    onChanged: (val) => setState(() => _includeSpecial = val!)),
                Text('Special'),
              ],
            ),
            SizedBox(height: 20),
            Text(
              _password,
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: _generate,
                  child: Text('Generate'),
                ),
                ElevatedButton(
                  onPressed: _update,
                  child: Text('Update'),
                ),
                ElevatedButton(
                  onPressed: _copyToClipboard,
                  child: Text('Copy'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
